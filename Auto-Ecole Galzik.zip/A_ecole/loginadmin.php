
<html>
<head>
<title>Admin login</title>
    <meta charset="utf-8">
    <meta name="robots" content="index, follow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="Spectre.css CSS Framework is a lightweight, responsive and modern CSS framework for faster and extensible development. Spectre provides basic styles for typography and elements, flexbox based responsive layout system, pure CSS components and utilities with best practice coding and consistent design language.">
    <link rel="shortcut icon" href="../img/favicons/favicon.ico">
    <link rel="icon" href="../img/favicons/favicon.png">
    <link rel="stylesheet" href="spectre.min.css">
    <link rel="stylesheet" href="spectre-icons.min.css">
    <link rel="stylesheet" href="spectre-exp.min.css">
    <link rel="stylesheet" href="docs.min.css">
</head>
<body>
<form action="loga.php" method="post" >
		<table border="0" cellpadding="10" cellspacing="1" width="500" align="center" class="tblLogin">
			<tr class="tableheader">
			<td align="center" colspan="2">Compte administrateur</td>
			</tr>
			<tr class="tablerow">
			<td>
			<input type="text" name="userName" placeholder="User Name" class="login-input"></td>
			</tr>
			<tr class="tablerow">
			<td>
			<input type="password" name="password" placeholder="Password" class="login-input"></td>
			</tr>
			<tr class="tableheader">
			<td align="center" colspan="2"><input type="submit" name="submit" value="Submit" class="btnSubmit"></td>
			</tr>

		</table>
</form>
</body></html>

<?php
   
   $userName=$_POST["userName"];
    $password=$_POST["password"];

if ("secretaire" == $userName AND "azerty" == $password ){ 
session_start("location:adminzone.php");
    
    echo("Vous êtes bien connectée");
    header("location:adminzone.php");
    }
    
else{
    header ("location:loginadmin.php");
    }
?>
