<?php if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start("ob_gzhandler"); else ob_start(); header('Content-type: text/html; charset=utf-8');?>
<!doctype html>
<?php
include('config.php')
?>
<!DOCTYPE html PUBLIC >
<html >
    <head>
          <head>
      <meta charset="utf-8">
    <meta name="robots" content="index, follow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="Spectre.css CSS Framework is a lightweight, responsive and modern CSS framework for faster and extensible development. Spectre provides basic styles for typography and elements, flexbox based responsive layout system, pure CSS components and utilities with best practice coding and consistent design language.">
    <link rel="shortcut icon" href="../img/favicons/favicon.ico">
    <link rel="icon" href="../img/favicons/favicon.png">
    <link rel="stylesheet" href="spectre.min.css">
    <link rel="stylesheet" href="spectre-icons.min.css">
    <link rel="stylesheet" href="spectre-exp.min.css">
    <link rel="stylesheet" href="docs.min.css">
        
    </head>
        <title>Espace membre</title>
    </head>
    <body>
    	  </head>
        <div class="section bg-gray">
            <br>
            <br>
      <H1><center>Espace documentaire</center></H1>
    </div>
<?php
//On affiche un message de bienvenue, si l'utilisateur est connecté, on affiche son pseudo
?>
<h2> Bonjour </h2>
<br>
<br>
Bienvenue sur la plateforme documentaire de l'auto école Glazik. Sur cette espace les futurs inscrits comme licenciés peuvent deposés leurs documents nécéssaire à la validation de leurs formations . <br />
<br>
<br>

<?php
//Si l'utilisateur est connecté, on lui donne un lien pour modifier ses informations, pour voir ses messages et un pour se déconnecter
if(isset($_SESSION['username']))
{
?>
<a href="edit_infos.php">Modifier mes informations personnelles</a><br />
<a href="connexion.php">Se d&eacute;connecter</a>
<?php
}
else
{
//Sinon, on lui donne un lien pour séinscrire et un autre pour se connecter
?>
<button class="btn"><a href="sign_up.php">Inscription</a></button>
<button class="btn"><a href="connexion.php">Se connecter</a></button>
<button class="btn"><a href="index.html">Quitter l'espace </a></button>
<?php
}
?>
		</div>
	</body>
</html>